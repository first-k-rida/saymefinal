const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, PutCommand } = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient({ region: process.env.AWS_REGION });
const docClient = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
  console.log("Cognito Post Confirmation Event:", JSON.stringify(event, null, 2));

  const emailVerified = event.request.userAttributes.email_verified === 'true';
  
  if (!emailVerified) {
    console.error("❌ Email not verified.");
    throw new Error("Email verification required");
  }

  const userId = event.request.userAttributes.sub;
  const email = event.request.userAttributes.email;
  const username = event.request.userAttributes.name || email.split('@')[0];
  
  const now = new Date().toISOString();

  const userProfile = {
    userId: userId,
    email: email,
    username: username,
    createdAt: now,
    lastLoginAt: now,
    paymentStatus: "trial",
    paymentConfirmedAt: null,
    consultationStatus: "pending",
    consultationDate: null,
    preSurveyCompleted: false,
    inputMethod: "text",
    notificationEmail: true,
    dailyReminder: true,
    reminderTime: "21:00",
    consecutiveMonths: 0,
    discountCount: 0,
    totalChallenges: 0,
    completedChallenges: 0,
    name: null,
    phoneNumber: null,
    gender: null,
    birthDate: null,
    birthTime: null,
    birthCity: null,
    birthCountry: null,
    bankAccount: null,
    accountStatus: "active",
    emailVerified: true,
    profileImage: null,
    updatedAt: now
  };

  try {
    const command = new PutCommand({
      TableName: "sayme-users",
      Item: userProfile,
      ConditionExpression: "attribute_not_exists(userId)"
    });

    await docClient.send(command);
    
    console.log("✅ User profile created successfully:", userId);
    return event;
    
  } catch (error) {
    console.error("❌ Error creating user profile:", error);
    
    if (error.name === 'ConditionalCheckFailedException') {
      console.log("User already exists, skipping creation");
      return event;
    }
    
    throw error;
  }
};